CIRCLERSLAB BUILD PACK

scenes/                      all scene art
  NN-name.webp               desktop scenes (1600x900)
  m-NN-name.webp             phone scenes (720x1280; portal 760x1350)
  sig-NN-name.webp           desktop blue-signal overlays (transparent)
  m-sig-NN-name.webp         phone blue-signal overlays
  Not yet available: m-06-engineering.webp and m-sig-06-engineering.webp
  (the Engineering portrait is pending; the app falls back to a crop of the desktop frame)
scenes.config.json           timings, transitions, hotspot rectangles, labels, related links
reference/circlerslab-flight-reference.html
                             working reference of the final behaviour. Open it in a browser
                             (keep the scenes/ folder next to reference/). Port its logic;
                             do not redesign it.
